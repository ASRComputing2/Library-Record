from flask import Flask, render_template, request, redirect, url_for, flash
from flask_sqlalchemy import SQLAlchemy
import datetime

app = Flask(__name__)
app.secret_key = 'your_secret_key'  # Needed for flash messages

# Configure the database
app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///booksborrowed.db'
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False

# Initialize the database
db = SQLAlchemy(app)

# Define the BorrowedBook model
class BorrowedBook(db.Model):
    id = db.Column(db.Integer, primary_key=True, nullable=False)
    title = db.Column(db.String(100), nullable=False)
    borrow_date = db.Column(db.String(20), nullable=False)
    borrower_name = db.Column(db.String(255), nullable=False)

    def __repr__(self):
        return f'<BorrowedBook {self.title}>'

# Create the database and the model
with app.app_context():
    db.create_all()

def calculate_days_passed(borrow_date):
    # Calculate the number of days passed since the borrow date
    borrow_date = datetime.datetime.strptime(borrow_date, "%Y-%m-%d")
    days_passed = (datetime.datetime.now() - borrow_date).days
    return days_passed

def determine_urgency(days_passed):
    if days_passed > 14:
        return "Overdue"
    elif 10 < days_passed <= 14:
        return 'high'
    elif 4 < days_passed <= 10:
        return 'medium'
    else:
        return 'low'

@app.route('/')
def index():
    # Retrieve all borrowed books from the database
    books_borrowed = BorrowedBook.query.all()
    # Calculate days passed and urgency for each borrowed book and pass it to the template
    books_with_details = [
        {
            "title": book.title,
            "borrow_date": book.borrow_date,
            "days_passed": calculate_days_passed(book.borrow_date),
            "borrower_name": book.borrower_name,
            "urgency": determine_urgency(calculate_days_passed(book.borrow_date)),
            "id": f'{book.id:04}'  # Pad the ID with four zeros
        } for book in books_borrowed
    ]
    return render_template('index.html', books=books_with_details)

@app.route('/add', methods=['POST'])
def add():
    title = request.form['title']
    borrow_date = request.form['borrow-date']
    borrower_name = request.form['borrower-name']

    # Create a new BorrowedBook object and add it to the database
    new_book = BorrowedBook(title=title, borrow_date=borrow_date, borrower_name=borrower_name)
    db.session.add(new_book)
    db.session.commit()

    flash('New borrowed book added successfully!', 'success')
    return redirect(url_for('index'))

@app.route('/search', methods=['GET'])
def search():
    search_term = request.args.get('search_term', '').strip()

    # Check if search term is a digit for searching by ID
    if search_term.isdigit():
        padded_id = int(search_term)  # Convert to integer to match database ID type
        results = BorrowedBook.query.filter_by(id=padded_id).all()
    else:
        # Search the database for books based on title, borrow date, or borrower name
        results = BorrowedBook.query.filter(
            BorrowedBook.title.contains(search_term) |
            BorrowedBook.borrow_date.contains(search_term) |
            BorrowedBook.borrower_name.contains(search_term)
        ).all()

    # Calculate days passed and urgency for each book in the search results
    books_with_details = [
        {
            "title": book.title,
            "borrow_date": book.borrow_date,
            "days_passed": calculate_days_passed(book.borrow_date),
            "borrower_name": book.borrower_name,
            "urgency": determine_urgency(calculate_days_passed(book.borrow_date)),
            "id": f'{book.id:04}'  # Pad the ID with four zeros
        } for book in results
    ]
    return render_template('index.html', books=books_with_details)

@app.route('/delete/<int:id>', methods=['POST'])
def delete(id):
    try:
        book = BorrowedBook.query.get(id)
        if book:
            db.session.delete(book)
            db.session.commit()
            flash('Record successfully deleted.', 'success')
        else:
            flash('Record not found.', 'error')
    except Exception as e:
        db.session.rollback()
        flash(f'An error occurred: {str(e)}', 'error')
    return redirect(url_for('index'))

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=6969)
